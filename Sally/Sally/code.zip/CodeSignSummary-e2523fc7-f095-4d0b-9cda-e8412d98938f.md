 | FileName             | Status | FileSize | TotalTime(sec) | Upload(sec) | Submit(sec) | SignWait(sec) | Retry Count | 
 |----------------------|--------|----------|----------------|-------------|-------------|---------------|-------------|
 | icudt66.dll          | Pass   | 26.75MB  | 27.31          | 2.11        | 0.58        | 24.61         | 0           | 
 | icutu66.dll          | Pass   | 223.88KB | 15.98          | 0.85        | 0.31        | 13.27         | 0           | 
 | icuio66.dll          | Pass   | 68.88KB  | 15.97          | 0.73        | 0.32        | 13.27         | 0           | 
 | icuuc66.dll          | Pass   | 1.82MB   | 15.96          | 1.8         | 0.38        | 13.27         | 0           | 
 | onnxruntime.dll      | Pass   | 6.04MB   | 27.3           | 1.72        | 0.32        | 24.61         | 0           | 
 | oc_sentencepiece.dll | Pass   | 710.88KB | 15.96          | 0.98        | 0.33        | 13.27         | 0           | 
 | icuin66.dll          | Pass   | 2.52MB   | 15.96          | 1.29        | 0.32        | 13.27         | 0           | 
 | oc_abi.dll           | Pass   | 1.15MB   | 15.96          | 1.07        | 0.32        | 13.27         | 0           | 
